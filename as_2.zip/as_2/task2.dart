 import 'dart:io';

void main() {
  stdout.write('Enter the radius of the circle: ');
  int radius = int.parse(stdin.readLineSync()!);
  
  double area = 3.14 * radius * radius; 
  print('The area of the circle is: $area');
}
