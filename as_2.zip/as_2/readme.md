### Overview task 1
<p style="font-family: 'Georgia', sans-serif;">This Dart program displays the current date and time when executed.</p>

### Overview task 2
<p style="font-family: 'Georgia', sans-serif;">Circle Area Calculator</p>
<p style="font-family: 'Georgia', sans-serif;">Description:</p>
<p style="font-family: 'Georgia', sans-serif;">This Dart console application calculates and prints the area of a circle based on user input for the radius. The program assumes the value of π (pi) as approximately 3.14159. </p>

### Overview: task 3
<p style="font-family: 'Georgia', sans-serif;">This Dart program helps you find the area of a triangle. You just need to enter the base and height when prompted.</p>

<p style="font-family: 'Georgia', sans-serif;">Open Dart on the computer.</p>
<p style="font-family: 'Georgia', sans-serif;">Run the Dart file.
Follow the prompts to enter the base and height.</p>

### Overview task 4
<p style="font-family: 'Georgia', sans-serif;"> The output of this task will represent the desired number of fibonacci numbers </p>

<p style="font-family: 'Georgia', sans-serif;">The user should follow the instructions on the terminal for getting the right number. </p>

<p style="font-family: 'Georgia', sans-serif;">For instance, app will ask to enter a number of how many fibonacci numbers does the user want to have as the output. </p>

<p style="font-family: 'Georgia', sans-serif;">Then it prints this number on the screen.</p> 


