void showCurrentDateTime() {
  DateTime now = DateTime.now();
  print('Current Date and Time: $now');
}

void main() {
  showCurrentDateTime();
}